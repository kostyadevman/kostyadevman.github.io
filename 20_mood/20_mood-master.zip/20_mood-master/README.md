# Site for the Mood

Every time you visit this site, the one funny quotes apears.

# Project Goals

The code is written for educational purposes. Training course for web-developers - [DEVMAN.org](https://devman.org)
